#ifndef HEXASERVER_H
#define HEXASERVER_H

#include <QObject>

#include <QtCore/QObject>
#include <QtCore/QList>
#include <QtCore/QByteArray>
#include <QTimer>

QT_FORWARD_DECLARE_CLASS(QWebSocketServer)
QT_FORWARD_DECLARE_CLASS(QWebSocket)

class HexaServer : public QObject
{
    Q_OBJECT
public:
    explicit HexaServer(quint16 port, QObject *parent = Q_NULLPTR);
    virtual ~HexaServer();

private Q_SLOTS:
    void onNewConnection();
    void processMessage(QString message);
    void socketDisconnected();
    void pingClients();
    void pongReceived();
    void chkPongList(); //disconnects the clients who not send pong signal to server

private:
    int nClientsConnected(); //return the number of active connected clients
    QWebSocketServer *m_pWebSocketServer;
    QList<QWebSocket *> m_clients;
    QList<QWebSocket *> pongList;
};

#endif // HEXASERVER_H
