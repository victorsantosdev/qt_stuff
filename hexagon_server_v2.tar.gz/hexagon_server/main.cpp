/*  ********************************************************************************
 * Copyright (C) 2017 Victor Santos <viic.santos@gmail.com>.
 * Contact: https://github.com/victorsantosdev
 *
 *   Websocket Server POC for Hexagon Company

Description: Implement a websocket server that accepts multiple connections.
You can base your implementation on the examples shown here: http://doc.qt.io/qt-5/qtwebsockets-examples.html

Additional requirements:
 - The server class must have a method that returns the current number of accepted connections.
 - The server must periodically check if the connections are still alive. If the connection is not alive the server must close the connection.
 Tip: check the existing methods in http://doc.qt.io/qt-5/qwebsocket.html

 To Compile: make

 Usage: ./hexagon_server

 Testing: run hexagon_server in a terminal, and open the file wsclient.html in a browser (tested with Firefox 51.0.1 (64-bit)).
 You can see the software requirements in the terminal which hexagon_server was been oppened.

 Tested on Arch Linux 64 bits 4.9.8-1-ARCH
 ******************************************************************************** */

#include <QCoreApplication>
#include "hexaserver.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    HexaServer server(1234);
    return a.exec();
}
