#include "hexaserver.h"

#include "QtWebSockets/QWebSocketServer"
#include "QtWebSockets/QWebSocket"
#include <QtCore/QDebug>
#include <QObject>
#include <QDebug>

QT_USE_NAMESPACE

HexaServer::HexaServer(quint16 port, QObject *parent) :
    QObject(parent),
    m_pWebSocketServer(Q_NULLPTR)
{
    m_pWebSocketServer = new QWebSocketServer(QStringLiteral("Hexagon Test Server"),
                                              QWebSocketServer::NonSecureMode,
                                              this);
    if (m_pWebSocketServer->listen(QHostAddress::Any, port))
    {
        qDebug() << "Hexagon Server listening on port: " << port;
        connect(m_pWebSocketServer, &QWebSocketServer::newConnection,
                this, &HexaServer::onNewConnection);
        QTimer *timer = new QTimer(this);
        connect(timer, &QTimer::timeout, this, &HexaServer::pingClients);
        timer->start(10000); //10 ping timeout
    }
    else {
        qDebug() << "Error: Server not started.";
    }
}

HexaServer::~HexaServer()
{
    m_pWebSocketServer->close();
    qDeleteAll(m_clients.begin(), m_clients.end());
}

void HexaServer::onNewConnection()
{
    QWebSocket *pSocket = m_pWebSocketServer->nextPendingConnection();

    connect(pSocket, &QWebSocket::textMessageReceived, this, &HexaServer::processMessage);
    //connect(pSocket, &QWebSocket::disconnected, this, &HexaServer::socketDisconnected);
    //if not commented, the server will call HexaServer::socketDisconnected as soon it receives the disconnect signal from QWebSocket object
    connect(pSocket, &QWebSocket::pong, this, &HexaServer::pongReceived);

    m_clients << pSocket;
    qDebug() << "Client connected - HOST:" <<pSocket->peerAddress() << " PORT:" << pSocket->peerPort();
    qDebug() << nClientsConnected() << " clients alive now";
    //qDebug() << "current ponglist: " << pongList;

}

void HexaServer::processMessage(QString message)
{
    QWebSocket *pSender = qobject_cast<QWebSocket *>(sender());
    for (QWebSocket *pClient : qAsConst(m_clients)) {
        if (pClient != pSender)
        {
            pClient->sendTextMessage(message);
        }
    }
}

void HexaServer::socketDisconnected()
{
    QWebSocket *pClient = qobject_cast<QWebSocket *>(sender());
    if (pClient)
    {
        qDebug() << "Client HOST:" << pClient->peerAddress()<< " PORT:" << pClient->peerPort() << " disconnected";
        m_clients.removeAll(pClient);
        qDebug() << nClientsConnected() << " clients alive now";
        pClient->deleteLater();
    }
}

int HexaServer::nClientsConnected() {
    return m_clients.count();
}

void HexaServer::pongReceived()
{
    QWebSocket *pClient = qobject_cast<QWebSocket *>(sender());
    qDebug() << "HexaServer got new pong from HOST:" << pClient->peerAddress()<< " PORT:" << pClient->peerPort();
    pongList.removeAll(pClient);
    //qDebug() << "current ponglist: " << pongList;
}


void HexaServer::chkPongList()
{
    //disconnects from who didn't sent pong signal to server
    if (pongList.length() > 0) {
        for (int i=0; i< pongList.length(); i++) {
            qDebug() << "Client HOST:" << pongList[i]->peerAddress()<< " PORT:" << pongList[i]->peerPort() << " disconnected";
            m_clients.removeAll(pongList[i]);
            qDebug() << nClientsConnected() << " clients alive now";
            pongList[i]->deleteLater();
            pongList.removeAll(pongList[i]);
        }
    }
}


void HexaServer::pingClients() {

    if (m_clients.length() > 0) {
        qDebug() << "checking alive clients...";

        if (pongList.length() > 0) {
            qDebug() << "someone didn't send pong signal..";
            HexaServer::chkPongList();
        }
        qDebug() << nClientsConnected() << " clients alive now";

        for (int i=0; i< m_clients.length(); i++) {
            qDebug() << "ping HOST:" << m_clients[i]->peerAddress()<< " PORT:" << m_clients[i]->peerPort();
            m_clients[i]->ping();
            pongList << m_clients[i];
        }
    } else {
        qDebug() << "there are no clients connected to this server.";
    }
}
